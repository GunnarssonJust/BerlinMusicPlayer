package com.berlinmusicplayer;

import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SearchActivity extends AppCompatActivity {

    EditText searchInput;
    RecyclerView recyclerView;
    TextView emptyText;
    SearchResultAdapter searchResultAdapter;
    ArrayList<SearchResultItem> results = new ArrayList<>();

    // Debounce: Suche erst nach 300ms starten (nicht bei jedem Tastendruck)
    private final Handler debounceHandler = new Handler(Looper.getMainLooper());
    private Runnable debounceRunnable;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        searchInput = findViewById(R.id.search_input);
        recyclerView = findViewById(R.id.search_recyclerView);
        emptyText = findViewById(R.id.search_empty_text);

        searchResultAdapter = new SearchResultAdapter(this, results);
        recyclerView.setAdapter(searchResultAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        searchInput.requestFocus();

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                // Vorherige Suche abbrechen
                if (debounceRunnable != null) debounceHandler.removeCallbacks(debounceRunnable);

                String query = s.toString().trim();
                if (query.isEmpty()) {
                    results.clear();
                    searchResultAdapter.notifyDataSetChanged();
                    emptyText.setVisibility(View.GONE);
                    return;
                }

                // 300ms warten, dann suchen
                debounceRunnable = () -> performSearch(query);
                debounceHandler.postDelayed(debounceRunnable, 300);
            }
        });
    }

    private void performSearch(String query) {
        // Suche im Hintergrund-Thread
        executor.execute(() -> {
            ArrayList<SearchResultItem> newResults = new ArrayList<>();
            String lowerQuery = query.toLowerCase();

            ArrayList<MusicFiles> allSongs = MainActivity.musicFiles;
            if (allSongs == null) return;

            ArrayList<String> addedAlbums = new ArrayList<>();
            ArrayList<String> addedArtists = new ArrayList<>();

            for (MusicFiles song : allSongs) {
                // Songs suchen
                if (song.getTitle() != null &&
                    song.getTitle().toLowerCase().contains(lowerQuery)) {
                    newResults.add(new SearchResultItem(SearchResultItem.TYPE_SONG, song));
                }

                // Alben suchen (jedes Album nur einmal)
                if (song.getAlbum() != null &&
                    song.getAlbum().toLowerCase().contains(lowerQuery) &&
                    !addedAlbums.contains(song.getAlbum())) {
                    addedAlbums.add(song.getAlbum());
                    newResults.add(new SearchResultItem(SearchResultItem.TYPE_ALBUM, song));
                }

                // Artists suchen (jeden Artist nur einmal)
                if (song.getArtist() != null &&
                    song.getArtist().toLowerCase().contains(lowerQuery) &&
                    !addedArtists.contains(song.getArtist())) {
                    addedArtists.add(song.getArtist());
                    newResults.add(new SearchResultItem(SearchResultItem.TYPE_ARTIST, song));
                }
            }

            // UI im Main-Thread aktualisieren
            runOnUiThread(() -> {
                results.clear();
                results.addAll(newResults);
                searchResultAdapter.notifyDataSetChanged();
                emptyText.setVisibility(results.isEmpty() ? View.VISIBLE : View.GONE);
            });
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}
