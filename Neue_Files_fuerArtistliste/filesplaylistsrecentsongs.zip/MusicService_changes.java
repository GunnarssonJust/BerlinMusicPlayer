// In MusicService.java - in der start() Methode ergänzen:

public void start() {
    if (mediaPlayer != null) {
        mediaPlayer.start();
        isPlaying = true;
        
        // ← NEU: Song zu "Zuletzt gespielt" hinzufügen
        if (currentPlaylist != null && position >= 0 && position < currentPlaylist.size()) {
            String songId = currentPlaylist.get(position).getId();
            PlaylistManager.getInstance(getApplicationContext()).addToRecent(songId);
        }
        
        // ... Rest bleibt gleich
        showNotification(R.drawable.ic_notif_play);
        saveCurrentSongToPrefs();
        updateMediaSessionState();
        sendWidgetUpdate();
    }
}
