// In MusicAdapter.java - menuMore OnClickListener ersetzen:

holder.menuMore.setOnClickListener(v -> {
    PopupMenu popupMenu = new PopupMenu(mContext, v);
    popupMenu.getMenuInflater().inflate(R.menu.popup, popupMenu.getMenu());
    popupMenu.show();
    popupMenu.setOnMenuItemClickListener(item -> {
        if (item.getItemId() == R.id.delete) {
            deleteFile(position, v);
        } else if (item.getItemId() == R.id.add_to_playlist) {
            showAddToPlaylistDialog(position, v);
        }
        return true;
    });
});

// ─── Neue Methode: Playlist-Auswahl Dialog ────────────────────────
private void showAddToPlaylistDialog(int position, View v) {
    PlaylistManager manager = PlaylistManager.getInstance(mContext);
    ArrayList<PlaylistManager.Playlist> playlists = manager.getPlaylists();

    if (playlists.isEmpty()) {
        com.google.android.material.snackbar.Snackbar.make(v,
            "Keine Playlists vorhanden. Erst eine Playlist erstellen!",
            com.google.android.material.snackbar.Snackbar.LENGTH_LONG).show();
        return;
    }

    String[] names = new String[playlists.size()];
    for (int i = 0; i < playlists.size(); i++) {
        names[i] = playlists.get(i).name;
    }

    new android.app.AlertDialog.Builder(mContext)
        .setTitle("Zur Playlist hinzufügen")
        .setItems(names, (dialog, which) -> {
            manager.addSongToPlaylist(which, mFiles.get(position).getId());
            com.google.android.material.snackbar.Snackbar.make(v,
                "Song zu \"" + playlists.get(which).name + "\" hinzugefügt!",
                com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show();
        })
        .setNegativeButton("Abbrechen", null)
        .show();
}
