// In ViewPagerAdapter.java - alle 3 Methoden anpassen:

@NonNull
@Override
public Fragment createFragment(int position) {
    switch (position) {
        case 0:
            if (mainActivity.songsFragment == null) {
                mainActivity.songsFragment = new SongsFragment();
            }
            return mainActivity.songsFragment;
        case 1:
            if (mainActivity.albumFragment == null) {
                mainActivity.albumFragment = new AlbumFragment();
            }
            return mainActivity.albumFragment;
        case 2:
            if (mainActivity.artistFragment == null) {
                mainActivity.artistFragment = new ArtistFragment();
            }
            return mainActivity.artistFragment;
        case 3:
            if (mainActivity.playlistFragment == null) {
                mainActivity.playlistFragment = new PlaylistFragment();
            }
            return mainActivity.playlistFragment;
        case 4:
            if (mainActivity.recentFragment == null) {
                mainActivity.recentFragment = new RecentFragment();
            }
            return mainActivity.recentFragment;
        default:
            return new SongsFragment();
    }
}

@Override
public int getItemCount() {
    return 5;  // ← War 3!
}

public CharSequence getPageTitle(int position) {
    switch (position) {
        case 0: return "Titel";
        case 1: return "Alben";
        case 2: return "Künstler";
        case 3: return "Playlists";
        case 4: return "Zuletzt";
        default: return "Titel";
    }
}
