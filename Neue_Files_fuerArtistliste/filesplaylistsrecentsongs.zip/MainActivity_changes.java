// In MainActivity.java - neue Fragment-Variablen hinzufügen:

// ALT:
SongsFragment songsFragment;
AlbumFragment albumFragment;
ArtistFragment artistFragment;

// NEU:
SongsFragment songsFragment;
AlbumFragment albumFragment;
ArtistFragment artistFragment;
PlaylistFragment playlistFragment;   // ← NEU
RecentFragment recentFragment;       // ← NEU
